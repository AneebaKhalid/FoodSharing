package com.example.myfirstapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class AllProducts extends RecyclerView.Adapter<AllProducts.ProductsViewHolder>{
    private Context mContext;
    private List<Products> productsList;

    public AllProducts(Context context, List<Products> products){

        mContext = context;
        productsList = products;

    }

    @NonNull
    @Override
    public AllProducts.ProductsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.activity_showproducts, parent, false);
        return new ProductsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AllProducts.ProductsViewHolder holder, int position) {
        Products products=productsList.get(position);
        holder.productName.setText(products.getProductName());
        //holder.productLocation.setText(products.getProductLocation());
        holder.productPrice.setText(String.valueOf(products.getProductPrice()));
        Picasso.get().load(products.getProductImageUri()).centerCrop().fit().into(holder.productImages);
        if (holder.productImages!=null){
            holder.productImages.setMaxHeight(100);
        }

    }

    @Override
    public int getItemCount() {
        return productsList.size();
    }


    public class ProductsViewHolder extends RecyclerView.ViewHolder{
        private ImageView productImages;
        private TextView productName;
        private TextView productLocation;
        private TextView productPrice;
        private TextView productDescription;
        private TextView productRegion;

        public ProductsViewHolder(@NonNull View itemView) {
            super(itemView);
            productImages = itemView.findViewById(R.id.productImages);
            productName = itemView.findViewById(R.id.productTitle);
            productPrice = itemView.findViewById(R.id.productPrice);
           // productLocation = itemView.findViewById(R.id.productLocation);
        }
    }
}
