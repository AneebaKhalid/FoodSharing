package com.example.myfirstapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.login.widget.LoginButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Dashboard extends AppCompatActivity implements View.OnClickListener {
    private ViewFlipper viewFlipper;
    private Button btnSignUp,loginBtn;
    private TextView txtViewGuest;
    private LoginButton facebookBtn;
    private DatabaseReference mDatabaseReference;
    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener mFirebaseAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        btnSignUp = (Button) findViewById(R.id.btnSignUp);
        loginBtn = (Button) findViewById(R.id.btnLogin);
        txtViewGuest = (TextView) findViewById(R.id.browse);
        facebookBtn = (LoginButton) findViewById(R.id.fb_login_button);


        viewFlipper = findViewById(R.id.slider);
        int sliderImagesList[] = {R.drawable.slider1,R.drawable.slider2,R.drawable.slider3,R.drawable.slider4,R.drawable.slider5,R.drawable.slider6};
        btnSignUp.setOnClickListener(this);
        loginBtn.setOnClickListener(this);
        facebookBtn.setOnClickListener(this);



        for (int image:sliderImagesList){
            imagesFlipper(image);
        }
        firebaseAuth = FirebaseAuth.getInstance();
        //firebaseStorageReference=firebasestorage.getReference("User");
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        txtViewGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Dashboard.this, showproducts.class);
                startActivity(intent);
            }
        });
        firebaseAuth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth==null){

                   // loginBtn.setVisibility(View.VISIBLE);
                   // btnSignUp.setVisibility(View.VISIBLE);
                }
                else{
                   // loginBtn.setVisibility(View.GONE);
                   // btnSignUp.setVisibility(View.GONE);
                   // Intent intent= new Intent(Dashboard.this, ShowData.class);
                   // startActivity(intent);

                }
            }
        });

        if (currentUser!=null){



        }
        else{
            loginBtn.setVisibility(View.VISIBLE);
            btnSignUp.setVisibility(View.VISIBLE);
        }
    }
    public void imagesFlipper(int image){
        ImageView imageView=new ImageView(this);
        imageView.setBackgroundResource(image);
        viewFlipper.addView(imageView);
        viewFlipper.setFlipInterval(2000);
        viewFlipper.setAutoStart(true);

        //Animation
        viewFlipper.setInAnimation(this, android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(this, android.R.anim.slide_out_right);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSignUp:
                startActivity(new Intent(this, Register.class));
                break;
        }
        switch (v.getId()){
            case R.id.btnLogin:
                startActivity(new Intent(this, SignIn.class));
                break;
        }
        switch (v.getId()){
            case R.id.fb_login_button:
                Intent intent = new Intent(Dashboard.this, SignIn.class);
                startActivity(intent);
                break;
        }


    }
}
