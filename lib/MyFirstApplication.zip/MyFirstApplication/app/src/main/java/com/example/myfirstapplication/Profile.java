package com.example.myfirstapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class Profile extends RecyclerView.Adapter<Profile.UserProfileViewHolder>{
    private Context mContext;
    private List<User> mUsersList;

    public Profile(Context context, List<User> users){

        mContext = context;
        mUsersList = users;

    }
    @NonNull
    @Override
    public UserProfileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.profile_items, parent, false);
        return new UserProfileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserProfileViewHolder holder, int position) {
        User currentUser= mUsersList.get(position);
        holder.name.setText(currentUser.getUserName());
        holder.email.setText(currentUser.getUserEmail());
        holder.gender.setText(currentUser.getSex());
        holder.country.setText(currentUser.getUserCountry());
        holder.phoneNumber.setText(currentUser.getUserPhoneNumber());
        Picasso.get().load(currentUser.getUserProfilePicUrl()).fit().centerCrop().into(holder.profileImgView);
    }

    @Override
    public int getItemCount() {
        return mUsersList.size();
    }

    public class UserProfileViewHolder extends RecyclerView.ViewHolder{
        private ImageView profileImgView;
        private TextView phoneNumber;
        private TextView email;
        private TextView name;
        private TextView country;
        private TextView gender;

        public UserProfileViewHolder(@NonNull View itemView) {
            super(itemView);

            profileImgView = itemView.findViewById(R.id.userProfileImage);
            phoneNumber = itemView.findViewById(R.id.userPhoneNumber);
            email = itemView.findViewById(R.id.userEmail);
            name = itemView.findViewById(R.id.userName);
            country = itemView.findViewById(R.id.userCountry);
            gender = itemView.findViewById(R.id.userGender);
        }
    }


}
