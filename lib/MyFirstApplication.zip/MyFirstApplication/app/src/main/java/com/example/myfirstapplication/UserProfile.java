package com.example.myfirstapplication;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UserProfile extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Profile profileAdapter;

    private DatabaseReference mDatabaseRef;
    private FirebaseAuth mFirebaseAuth;
    private List<User> usersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        recyclerView = findViewById(R.id.userProfileRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        usersList = new ArrayList<>();

        mDatabaseRef = FirebaseDatabase.getInstance().getReference("User");
        mFirebaseAuth = FirebaseAuth.getInstance();

        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (mFirebaseAuth.getCurrentUser()!= null){
                    for (DataSnapshot userDataSnapshot: dataSnapshot.getChildren()){
                    User user= userDataSnapshot.getValue(User.class);
                    usersList.add(user);
                    }
                    profileAdapter = new Profile(UserProfile.this, usersList);
                    recyclerView.setAdapter(profileAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UserProfile.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}
